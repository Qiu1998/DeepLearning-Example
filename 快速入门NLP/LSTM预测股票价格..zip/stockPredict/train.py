from torch.autograd import Variable
import torch.nn as nn
import torch
import numpy as np
import matplotlib.pyplot as plt
from LSTMModel import lstm
from parser_my import args
from dataset import getData
loss_log=[]
def train():

    model = lstm(input_size=args.input_size, hidden_size=args.hidden_size, num_layers=args.layers , output_size=1, dropout=args.dropout, batch_first=args.batch_first )
    model.to(args.device)
    criterion = nn.MSELoss()  # 定义损失函数
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)  # Adam梯度下降  学习率=0.001

    close_max, close_min, train_loader, test_loader = getData(args.corpusFile,args.sequence_length,args.batch_size )
    for i in range(args.epochs):
        total_loss = 0
        # 在 train() 函数中修改这部分：
        for idx, (data, label) in enumerate(train_loader):
            if args.useGPU:
                # 不再需要 squeeze(1)，因为数据形状已经是正确的
                data1 = data.cuda()
                pred = model(Variable(data1).cuda())
                # 根据你的 LSTM 模型输出调整这部分
                pred = pred[1, :, :]  # 如果这是正确的索引
                label = label.unsqueeze(1).cuda()  # 确保标签形状匹配
            else:
                data1 = data
                pred = model(Variable(data1))
                pred = pred[1, :, :]
                label = label.unsqueeze(1)
            loss = criterion(pred, label)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        print(total_loss)
        if(total_loss <0.05):
            loss_log.append(total_loss)
        if i % 10 == 0:
            # torch.save(model, args.save_file)
            torch.save({'state_dict': model.state_dict()}, args.save_file)
            print('第%d epoch，保存模型' % i)
    # torch.save(model, args.save_file)
    torch.save({'state_dict': model.state_dict()}, args.save_file)

train()

plt.plot(loss_log, 'r-')
plt.title('Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')

plt.tight_layout()
plt.show()