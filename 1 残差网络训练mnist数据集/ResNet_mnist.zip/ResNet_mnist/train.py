import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

# 自定义CSV Dataset类
class MNISTCSVDataset(Dataset):
    def __init__(self, csv_file, transform=None):
        """
        Args:
            csv_file (string): CSV文件的路径
            transform (callable, optional): 可选的图像变换
        """
        self.data = pd.read_csv(csv_file)
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # 第一列通常是标签，其余列是像素值
        label = self.data.iloc[idx, 0]
        # 获取像素值（从第二列开始）
        pixels = self.data.iloc[idx, 1:].values.astype(np.float32)

        # 将一维数组重塑为28x28图像
        image = pixels.reshape(28, 28)

        # 转换为[0,1]范围的浮点数（如果像素值在0-255之间）
        if pixels.max() > 1.0:
            image = image / 255.0

        # 添加通道维度并应用变换
        image = np.expand_dims(image, axis=0)  # 形状变为 (1, 28, 28)

        if self.transform:
            image = self.transform(torch.from_numpy(image))
        else:
            image = torch.from_numpy(image)

        return image, label


# 数据集路径
dataset_path = 'mnist_dataset'

# 使用完整的训练集和测试集
train_filepath = os.path.join(dataset_path, 'mnist_train.csv')
test_filepath = os.path.join(dataset_path, 'mnist_test.csv')

print(f"使用训练集: {train_filepath}")
print(f"使用测试集: {test_filepath}")

# 检查文件是否存在
if not os.path.exists(train_filepath):
    print(f"错误: 训练集文件 {train_filepath} 不存在!")
    exit()
if not os.path.exists(test_filepath):
    print(f"错误: 测试集文件 {test_filepath} 不存在!")
    exit()

# 数据变换
transform = transforms.Compose([
    transforms.Normalize((0.1307,), (0.3081,))  # MNIST的标准归一化参数
])

# 使用CSV数据集
train_data = MNISTCSVDataset(
    csv_file=train_filepath,
    transform=transform
)

test_data = MNISTCSVDataset(
    csv_file=test_filepath,
    transform=transform
)

print(f"训练集大小: {len(train_data)}")
print(f"测试集大小: {len(test_data)}")


# 残差模块
class ResBlock(nn.Module):
    def __init__(self, channel_in):
        super().__init__()
        self.conv1 = nn.Conv2d(channel_in, 30, 5, padding=2)
        self.conv2 = nn.Conv2d(30, channel_in, 3, padding=1)

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        return torch.relu(out + x)


class ResNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, 5)
        self.conv2 = nn.Conv2d(32, 64, 3)
        self.conv3 = nn.Conv2d(64, 128, 3)
        self.maxpool = nn.MaxPool2d(2)
        self.resblock1 = ResBlock(channel_in=32)
        self.resblock2 = ResBlock(channel_in=64)
        self.resblock3 = ResBlock(channel_in=128)
        self.full_c = nn.Linear(128, 10)

    def forward(self, x):
        size = x.shape[0]
        x = torch.relu(self.maxpool(self.conv1(x)))
        x = self.resblock1(x)
        x = torch.relu(self.maxpool(self.conv2(x)))
        x = self.resblock2(x)
        x = torch.relu(self.maxpool(self.conv3(x)))
        x = self.resblock3(x)
        x = x.view(size, -1)
        x = self.full_c(x)
        return x


train_loader = DataLoader(train_data, batch_size=64, shuffle=True)
test_loader = DataLoader(test_data, batch_size=64, shuffle=False)

# 修复设备选择问题
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f'Using {device} device')
model = ResNet().to(device)


def train(dataloader, model, loss_fn, optimizer):
    model.train()
    batch_size_num = 0
    loss_sum = 0
    batch_losses = []  # 记录每个batch的loss
    
    for X, y in dataloader:
        X, y = X.to(device), y.to(device)
        pred = model(X)
        loss = loss_fn(pred, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        loss_value = loss.item()
        loss_sum += loss_value
        batch_losses.append(loss_value)  # 记录loss
        
        if batch_size_num % 100 == 0:
            print(f'loss:{loss_value:>7f} [number:{batch_size_num}]')
        batch_size_num += 1
        
    return loss_sum / max(batch_size_num, 1), batch_losses  # 返回平均loss和所有batch的loss


def test(dataloader, model, loss_fn):
    model.eval()
    len_data = len(dataloader.dataset)
    correct, loss_sum = 0, 0
    num_batch = 0
    with torch.no_grad():
        for X, y in dataloader:
            X, y = X.to(device), y.to(device)
            pred = model(X)
            loss_sum += loss_fn(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
            num_batch += 1
        loss_avg = loss_sum / max(num_batch, 1)
        accuracy = correct / len_data
        print(f'Accuracy: {100 * accuracy:.2f}%')
        print(f'Loss Avg: {loss_avg:.6f}')
        print(f'Correct: {correct}/{len_data}')
    return accuracy, loss_avg  # 返回准确率和测试loss


# 绘制loss曲线并保存
def plot_loss_curves(train_losses, test_losses, train_batch_losses, accuracies, save_path='loss_curves.png'):
    plt.figure(figsize=(15, 5))
    
    # 子图1：训练loss和测试loss
    plt.subplot(1, 3, 1)
    plt.plot(range(1, len(train_losses) + 1), train_losses, 'b-', label='Train Loss', linewidth=2)
    plt.plot(range(1, len(test_losses) + 1), test_losses, 'r-', label='Test Loss', linewidth=2)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Test Loss')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 子图2：batch级别的训练loss（更详细）
    plt.subplot(1, 3, 2)
    all_batch_losses = [loss for epoch_losses in train_batch_losses for loss in epoch_losses]
    plt.plot(range(1, len(all_batch_losses) + 1), all_batch_losses, 'g-', alpha=0.7, linewidth=1)
    plt.xlabel('Batch Number')
    plt.ylabel('Loss')
    plt.title('Batch-level Training Loss')
    plt.grid(True, alpha=0.3)
    
    # 子图3：准确率
    plt.subplot(1, 3, 3)
    plt.plot(range(1, len(accuracies) + 1), [acc * 100 for acc in accuracies], 'purple', linewidth=2)
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.title('Test Accuracy')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Loss曲线图已保存为: {save_path}")


# 在开始训练前，先检查一下数据格式
print("\n检查数据格式...")
for X, y in train_loader:
    print(f"输入数据形状: {X.shape}")  # 应该是 [64, 1, 28, 28]
    print(f"标签形状: {y.shape}")  # 应该是 [64]
    print(f"像素值范围: {X.min().item():.3f} ~ {X.max().item():.3f}")
    break

loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer=optimizer, step_size=3, gamma=0.5)

epochs = 20
best_accuracy = 0

# 用于记录训练过程的列表
train_losses = []
test_losses = []
train_batch_losses = []  # 记录每个epoch中所有batch的loss
accuracies = []

print("\n开始训练...")
for i in range(epochs):
    print(f'========== 第 {i + 1} 轮训练 ==============')
    avg_loss, batch_losses = train(train_loader, model, loss_fn, optimizer)
    train_losses.append(avg_loss)
    train_batch_losses.append(batch_losses)  # 记录这个epoch的所有batch loss
    
    scheduler.step()
    current_lr = optimizer.param_groups[0]['lr']
    print(f'第 {i + 1} 轮训练结束, 平均损失: {avg_loss:.6f}, 当前学习率: {current_lr:.6f}')

    # 每轮都测试，观察进度
    print("进行测试...")
    accuracy, test_loss = test(test_loader, model, loss_fn)
    test_losses.append(test_loss)
    accuracies.append(accuracy)
    
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        print(f"新的最佳准确率: {100 * best_accuracy:.2f}%")

print(f"\n训练完成！最终测试结果:")
final_accuracy, final_test_loss = test(test_loader, model, loss_fn)
print(f"最佳准确率: {100 * best_accuracy:.2f}%")

# 绘制并保存loss曲线
plot_loss_curves(train_losses, test_losses, train_batch_losses, accuracies)

# 额外保存一个简单的epoch级loss曲线
plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.plot(train_losses, 'b-o', label='Train Loss')
plt.plot(test_losses, 'r-o', label='Test Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Progress')
plt.legend()
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot([acc * 100 for acc in accuracies], 'g-o')
plt.xlabel('Epoch')
plt.ylabel('Accuracy (%)')
plt.title('Test Accuracy Progress')
plt.grid(True)

plt.tight_layout()
plt.savefig('training_progress.png', dpi=300, bbox_inches='tight')
plt.close()
print("训练进度图已保存为: training_progress.png")

# 保存训练数据到文件（可选）
training_data = {
    'train_losses': train_losses,
    'test_losses': test_losses,
    'accuracies': accuracies,
    'best_accuracy': best_accuracy
}
np.save('training_history.npy', training_data)
print("训练历史数据已保存为: training_history.npy")

# 在现有代码的最后添加以下内容

# 保存模型
def save_model(model, filepath):
    """保存模型到指定路径"""
    torch.save({
        'model_state_dict': model.state_dict(),
        'model_architecture': model.__class__.__name__
    }, filepath)
    print(f"模型已保存到: {filepath}")

# 创建模型保存目录
model_dir = 'saved_models'
os.makedirs(model_dir, exist_ok=True)

# 保存模型
model_path = os.path.join(model_dir, 'mnist_resnet_model.pth')
save_model(model, model_path)

print(f"\n训练完成！模型已保存。")
print(f"最终测试结果:")
test(test_loader, model, loss_fn)
print(f"最佳准确率: {100 * best_accuracy:.2f}%")