# predict.py
import torch
import torch.nn as nn
from torchvision import transforms
import numpy as np
from PIL import Image
import os

# 定义与训练时相同的模型结构
class ResBlock(nn.Module):
    def __init__(self, channel_in):
        super().__init__()
        self.conv1 = nn.Conv2d(channel_in, 30, 5, padding=2)
        self.conv2 = nn.Conv2d(30, channel_in, 3, padding=1)

    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        return torch.relu(out + x)

class ResNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 32, 5)
        self.conv2 = nn.Conv2d(32, 64, 3)
        self.conv3 = nn.Conv2d(64, 128, 3)
        self.maxpool = nn.MaxPool2d(2)
        self.resblock1 = ResBlock(channel_in=32)
        self.resblock2 = ResBlock(channel_in=64)
        self.resblock3 = ResBlock(channel_in=128)
        self.full_c = nn.Linear(128, 10)

    def forward(self, x):
        size = x.shape[0]
        x = torch.relu(self.maxpool(self.conv1(x)))
        x = self.resblock1(x)
        x = torch.relu(self.maxpool(self.conv2(x)))
        x = self.resblock2(x)
        x = torch.relu(self.maxpool(self.conv3(x)))
        x = self.resblock3(x)
        x = x.view(size, -1)
        x = self.full_c(x)
        return x

def load_model(model_path, device='cpu'):
    """加载训练好的模型"""
    model = ResNet()
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(device)
    model.eval()
    print(f"模型加载成功: {model_path}")
    return model

def preprocess_image(image_path):
    """预处理输入图像"""
    try:
        # 读取图像并转换为灰度
        image = Image.open(image_path).convert('L')
        
        # 调整大小为28x28
        image = image.resize((28, 28))
        
        # 转换为numpy数组
        image_array = np.array(image).astype(np.float32)
        
        # 归一化到0-1
        if image_array.max() > 1.0:
            image_array = image_array / 255.0
        
        # 应用MNIST标准归一化
        transform = transforms.Normalize((0.1307,), (0.3081,))
        image_tensor = torch.from_numpy(image_array).unsqueeze(0)  # (1, 28, 28)
        image_tensor = transform(image_tensor)
        
        return image_tensor
    except Exception as e:
        print(f"图像预处理错误: {e}")
        return None

def predict_image(model, image_tensor, device='cpu'):
    """对图像进行预测"""
    with torch.no_grad():
        image_tensor = image_tensor.to(device)
        outputs = model(image_tensor.unsqueeze(0))  # 添加batch维度
        probabilities = torch.nn.functional.softmax(outputs[0], dim=0)
        predicted_class = torch.argmax(probabilities).item()
        confidence = probabilities[predicted_class].item()
    
    return predicted_class, confidence, probabilities

def main():
    # 设置设备
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'使用设备: {device}')
    
    # 模型路径
    model_path = 'saved_models/mnist_resnet_model.pth'
    
    # 检查模型文件是否存在
    if not os.path.exists(model_path):
        print(f"错误: 模型文件 {model_path} 不存在!")
        print("请先运行训练脚本训练并保存模型。")
        return
    
    # 加载模型
    model = load_model(model_path, device)
    
    # 固定的图像路径
    image_path = 'picture.png'
    
    # 检查图像文件是否存在
    if not os.path.exists(image_path):
        print(f"错误: 图像文件 {image_path} 不存在!")
        print("请确保在当前目录下有一个名为 'picture.png' 的手写数字图像。")
        return
    
    print(f"处理图像: {image_path}")
    
    # 预处理图像
    image_tensor = preprocess_image(image_path)
    if image_tensor is None:
        return
    
    # 进行预测
    predicted_class, confidence, probabilities = predict_image(model, image_tensor, device)
    
    # 显示结果
    print(f"\n预测结果: 数字 {predicted_class}")
    print(f"置信度: {confidence:.4f} ({confidence*100:.2f}%)")
    
    # 显示所有数字的概率
    print("\n所有数字的概率:")
    for i in range(10):
        prob = probabilities[i].item()
        print(f"数字 {i}: {prob:.4f} ({prob*100:.2f}%)")

if __name__ == "__main__":
    main()